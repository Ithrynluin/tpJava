package fr.unilim.info;

public enum SoinEnum {
	DENTS,
	PIEDS;
}
